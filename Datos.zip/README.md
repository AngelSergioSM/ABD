# AQUÍ SUBIREMOS DATOS PARA PROBAR
## Tablas: CLIENTE, EMPRESA, INDIVIDUAL, AUTORIZACIÓN, y PERSONA_AUTORIZADA
* El **cliente** con ID = 1 es **individual**, y se llama "Juan Pérez"
* El **cliente** con ID = 5 es **empresa**, de razón social "Mesas S.L"; relacionado con la persona_autorizada de ID 1.

## Tablas: CLIENTE (e hijos) y CUENTA (e hijos)
* Los **clientes** con ID 1, 2, 3, 4, 5 son **persona física** e **individual**. Sus **cuentas fintech** asignadas son las de ID 1, 2, 3, 4, 5. (ID de cliente y cuenta fintech concuerdan **sin tener por qué**; por simplicidad). 
* Todos tienen **estado** de alta menos el cliente de ID 2.
